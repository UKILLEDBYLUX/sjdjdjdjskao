package dev.silverandro.lootbeams;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.entity.ItemEntity;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.world.World;

public class ParticleGenerator {
    public static void generateParticles(ItemEntity entity, int color, LootbeamsConfig config) {
        // World.addParticle(effect, alwaysSpawn, ...) changed in 1.21.2+, so spawn straight through the
        // ParticleManager (which also keeps the "always spawn" behaviour for far away items).
        ParticleManager particles = MinecraftClient.getInstance().particleManager;
        World world = entity.getWorld();

        for (int i = 0; i < config.particleCount; i++) {
            // 1.21.2+: DustParticleEffect takes a packed RGB int instead of a Vector3f
            particles.addParticle(
                    new DustParticleEffect(color & 0xFFFFFF, 1.0f),
                    entity.getX(),
                    entity.getY() + config.beamOffset + (world.random.nextDouble() * config.beamHeight),
                    entity.getZ(),
                    0.0,
                    0.0,
                    0.0
            );
        }

        if (config.enchantedParticles && entity.getStack().hasGlint()) {
            for (int i = 0; i < Math.max(config.particleCount / 2, 1); i++) {
                particles.addParticle(
                        ParticleTypes.PORTAL,
                        entity.getX(),
                        entity.getY() + config.beamOffset + (world.random.nextDouble() * config.beamHeight),
                        entity.getZ(),
                        0.0,
                        -0.3,
                        0.0
                );
            }
        }
    }
}
